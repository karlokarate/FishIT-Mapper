package dev.fishit.mapper.contract

// Intentionally empty. All real contract types are generated into build/.
